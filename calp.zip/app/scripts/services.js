(function(){
	'use strict';

	/**
	* Serviços
	*
	* 
	*/
	angular.module('calpApp.services', [])
		.run(['$rootScope', function($rootScope){
			console.log('Serviços iniciados');
		}]);
})();