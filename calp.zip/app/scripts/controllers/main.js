'use strict';

/**
 * @ngdoc function
 * @name calpApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the calpApp
 */
angular.module('calpApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
