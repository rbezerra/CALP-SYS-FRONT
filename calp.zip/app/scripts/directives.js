'use strict';

angular.module('calpApp.directives', []);