'use strict';

/**
*  Module
*
* Description
*/
angular.module('calpApp.filters', [])
	.run(['$rootScope', function($rootScope){
		console.log('Filtros Carregados');
	}]);