'use strict';

angular.module('calpApp.controllers', [])
	.controller('MainController', ['$scope', function($scope){
		$scope.dias = [];

	}])

	.controller('LoginController', ['$scope', function($scope){
		
	}])

	.controller('UsuariosController',  function($scope){
      $scope.message = "FALTA IMPLEMENTAR";
  	})

	.controller('AlunosController',  function($scope){
	    $scope.message = "FALTA IMPLEMENTAR";
	})

	.controller('ProjetosController',  function($scope){
	    $scope.message = "FALTA IMPLEMENTAR";
	})

	.controller('SobreController',  function($scope){
	    $scope.message = "FALTA IMPLEMENTAR";
	})

	.run(['$rootScope', function($rootScope){
		console.log("Controllers carregados");
	}]);